THE RANKERS HUB WEBSITE

Files:
- index.html
- style.css
- script.js
- logo.png (your supplied logo)

To test on your computer:
1. Put all four files in the same folder.
2. Double-click index.html. It opens in Chrome.

To publish FREE:
1. Create a free account at github.com.
2. Create a NEW PUBLIC repository, e.g. therankershub-website.
3. Upload index.html, style.css, script.js and logo.png.
4. Go to Settings > Pages.
5. Under Build and deployment choose Deploy from a branch.
6. Select main and / (root), then Save.
7. GitHub gives you a github.io URL.
8. In Pages > Custom domain enter therankershub.in and save.
9. At the company where you bought therankershub.in, change DNS records to the GitHub Pages records GitHub shows you. GitHub's current documentation should be followed for the exact records.

Before advertising, replace:
- YOUR EMAIL HERE
- YOUR NUMBER HERE
- To be announced (location)

IMPORTANT: The interest form is currently only a browser demo. It stores the lead in the visitor's browser and does not send it to you. Connect it to a form/email service before using paid ads.
